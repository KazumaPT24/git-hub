# discord-oauth2
Simple Discord Oauth2, with auto join
